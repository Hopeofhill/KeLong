"""Configuration module for NNScholar application."""

from .settings import Config
from .api_config import APIConfig

__all__ = ['Config', 'APIConfig']